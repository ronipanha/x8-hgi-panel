plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.x8hgi.panel"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.x8hgi.panel"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
