package id.x8hgi.panel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var packageField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "X8 HGI PANEL"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Panel kontrol pendamping untuk Android"
            textSize = 15f
            setPadding(0, 8, 0, 20)
        })
        root.addView(TextView(this).apply {
            text = "Package name HGI (periksa dari info aplikasi HGI):"
            textSize = 14f
        })
        packageField = EditText(this).apply {
            setSingleLine(true)
            setText("com.neptune.domino")
            hint = "contoh: com.nama.aplikasi"
        }
        root.addView(packageField, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(makeButton("1. IZINKAN PANEL MENGAMBANG") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else toast("Izin panel sudah aktif.")
        })
        root.addView(makeButton("2. TAMPILKAN PANEL X8") {
            if (Settings.canDrawOverlays(this)) {
                val intent = Intent(this, OverlayPanelService::class.java)
                intent.putExtra(OverlayPanelService.EXTRA_GAME_PACKAGE, packageField.text.toString().trim())
                startService(intent)
            } else {
                toast("Aktifkan izin panel mengambang terlebih dahulu.")
            }
        })
        root.addView(makeButton("3. BUKA HGI") {
            val pkg = packageField.text.toString().trim()
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) startActivity(launch) else toast("Aplikasi tidak ditemukan. Periksa package name HGI.")
        })
        root.addView(TextView(this).apply {
            text = "\nCatatan: slider 1x–10x dan START/STOP adalah kontrol demo panel. Aplikasi ini tidak mengubah kecepatan internal HGI."
            textSize = 13f
        })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
