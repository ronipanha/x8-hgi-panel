package id.x8hgi.panel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class OverlayPanelService : Service() {
    companion object {
        const val EXTRA_GAME_PACKAGE = "game_package"
    }

    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var gamePackage = "com.neptune.domino"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        gamePackage = intent?.getStringExtra(EXTRA_GAME_PACKAGE) ?: gamePackage
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xEE20252B.toInt())
        }
        root.addView(TextView(this).apply {
            text = "X8 HGI • PANEL"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val speedText = TextView(this).apply {
            text = "Kecepatan demo: 1x"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(speedText)
        root.addView(SeekBar(this).apply {
            max = 9
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    speedText.text = "Kecepatan demo: ${value + 1}x"
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        })
        val state = TextView(this).apply {
            text = "STATUS: STOP"
            setTextColor(0xFFFFD180.toInt())
        }
        root.addView(state)
        root.addView(Button(this).apply {
            text = "START (DEMO)"
            setOnClickListener {
                state.text = "STATUS: START (DEMO)"
                Toast.makeText(this@OverlayPanelService,
                    "Panel demo aktif; HGI tidak dipercepat.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "STOP"
            setOnClickListener { state.text = "STATUS: STOP" }
        })
        root.addView(Button(this).apply {
            text = "BUKA HGI"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(gamePackage)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                } else Toast.makeText(this@OverlayPanelService,
                    "HGI tidak ditemukan. Periksa package name.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "TUTUP PANEL"
            setOnClickListener { stopSelf() }
        })

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 110
        }
        panel = root
        windowManager?.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) {}
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
