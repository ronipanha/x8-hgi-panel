# X8 HGI Panel — fresh Android project

Target: Android 8.0+; intended for testing on Samsung Galaxy A55.

## Included
- Launcher screen
- User-editable HGI package name (default is `com.neptune.domino`; verify it on the phone)
- Overlay permission flow
- Floating panel
- Demo speed slider 1x–10x
- START / STOP demo status
- Launch HGI button
- GitHub Actions workflow for a debug APK

## Important
The speed slider and START/STOP are UI demonstration controls only. They do not change HGI gameplay speed, memory, network traffic, or internal behavior. This project does not bypass anti-cheat or app protections.

## Build using GitHub from a phone
1. Create a new repository on GitHub named `x8-hgi-panel`.
2. Extract this ZIP on your phone.
3. Upload the **contents** of the extracted folder to the repository root (keep `.github/workflows/build-apk.yml` in its exact folder).
4. Open the repository's Actions tab and run **Build X8 HGI APK**, or push to the `main` branch.
5. When the workflow finishes successfully, open its run and download artifact `X8-HGI-debug-APK`.
6. Extract that artifact ZIP; it contains `app-debug.apk`.
7. Install the APK on the phone. Android may ask permission to install unknown apps for the browser or file manager.

This is a debug APK for testing and has not been compiled or verified on a physical phone in this environment.
